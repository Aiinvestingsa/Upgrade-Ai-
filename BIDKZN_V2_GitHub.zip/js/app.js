function toggleMenu(){document.getElementById('nav')?.classList.toggle('open')}
function demoLogin(e){e.preventDefault();location.href='dashboard.html'}
function demoRegister(e){e.preventDefault();alert('Demo account created. Connect a secure backend before using this for real users.');location.href='login.html'}
function demoNotice(e){e.preventDefault();document.getElementById('notice')?.replaceChildren(document.createTextNode('Demo submitted. Connect your backend/payment system for live processing.'))}
function loadVoucher(e){e.preventDefault();document.getElementById('notice').textContent='Demo voucher screen: voucher validation must be performed on a secure server.'}
let seconds=900;setInterval(()=>{let el=document.getElementById('timer');if(!el)return;seconds=Math.max(0,seconds-1);let m=String(Math.floor(seconds/60)).padStart(2,'0'),s=String(seconds%60).padStart(2,'0');el.textContent='00:'+m+':'+s},1000);
