# BID KZN V2
Professional Black & Gold static frontend for GitHub Pages.

## Important
This package is a frontend/demo foundation. Real passwords, ID numbers, wallets, payments, vouchers and bids must be handled by a secure backend/database. Do not deploy real-money bidding using browser-only storage.

## GitHub Pages
Upload the contents to the repository root and enable Pages from the repository's Settings > Pages. GitHub Pages publishes static HTML/CSS/JavaScript from a repository.
